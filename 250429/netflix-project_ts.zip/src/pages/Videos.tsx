

const Videos = () => {
  return (
    <div>Videos</div>
  )
}

export default Videos