

const Review = () => {
  return <div>Review</div>;
};

export default Review;
