// "use client";

// import { ReactNode } from "react";

// const ClientComponent = ({ children }: { children: ReactNode }) => {
//   console.log("클라이언트컴포넌트");
//   return <div>{children}</div>; //자식요소로 받아줌
// };

// export default ClientComponent;

/*

const person = {
name:"정휘찬"
age: 25
}
직렬화 한것
{"name":"정휘찬","age":25}

=> 객체, 배열, 클래스 등의 중첩형태의 자료구조를 띌 수 있는 자료구조 데이터를 네트워크 상으로 전송하기 위해서 아주 단순한 형태(문자열, 숫자 등)로 변환하는 것
json을 직렬화형 태기 때문 에 가져올 수 있다

=> 함수 => 직렬화가 불가능!!!

*/
