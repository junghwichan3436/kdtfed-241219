// import React from "react";

// const ServerComponent = () => {
//   console.log("서버컴포넌트");

//   return <div>ServerComponent</div>;
// };

// export default ServerComponent;
